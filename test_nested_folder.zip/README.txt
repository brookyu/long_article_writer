README file for the project
