Project overview document
